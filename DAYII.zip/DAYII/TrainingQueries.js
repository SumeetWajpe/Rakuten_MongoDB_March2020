//Implicit AND
db.courses.find({ "duration": "24 Hours", "price": 3000 }).pretty()

// $in
db.courses.find({ "title": { $in: ["React", "Angular"] } }).pretty()

// $nin
db.courses.find({ "title": { $nin: ["React", "Angular"] } }).pretty()

// mongoimport 
mongoimport--db usersdb--collection users--file users.json--jsonArray 

// Implicit AND
db.users.find({ "dob.age": { $gt: 30 }, "nat": "CA" })

// using $or
db.users.find({ $or: [{ "dob.age": { $gt: 30 } }, { "nat": "CA" }] }).pretty().limit(5)
// skip and limit and sort
db.users.find({ $or: [{ "dob.age": { $gt: 30 } }, { "nat": "CA" }] }).pretty().skip(5)

// sort : -1 is descending , 1 is ascending
db.users.find({ $or: [{ "dob.age": { $gt: 30 } }, { "nat": "CA" }] }).pretty().sort({"dob.age":1}).limit(5)

// Simple Aggregation pipeline

db.users.aggregate([
    { $match: { "gender": "male" } },
    { $group: { _id: { nat: "$nat" }, "usercount": { $sum: 1 } } },
    {$sort:{"usercount":1}}
]).pretty();

// To find users with age > 50 by gender,
// find avg age & number of users corresponding to that group
// & sort them descending

db.users.aggregate([
    { $match: { "dob.age": { $gt: 50 } } },
    { $group: { _id: { gender: "$gender" }, averageAge: { $avg: "$dob.age" }, usercount: { $sum: 1 } } },
    { $sort: {usercount:-1}}
]).pretty()


// the Project stage
db.users.aggregate([
    {
        $project: {
            _id: 0,           
            fullname: {
                $concat: [
                    { $toUpper: { $substrCP: ["$name.first", 0, 1] } },
                    {
                        $substrCP: [
                            "$name.first", 1, {
                                $subtract:[{$strLenCP:"$name.first"},1]
                            }
                        ]
                    },
                    " ",
                    { $toUpper: { $substrCP: ["$name.last", 0, 1] } },
                    {
                        $substrCP: [
                            "$name.last", 1, {
                                $subtract:[{$strLenCP:"$name.last"},1]
                            }
                        ]
                    },    
                ]
            },
            gender: 1,
            age: "$dob.age",
            location: {
                coordinates: [
                    {
                        $convert: {
                            input: "$location.coordinates.longitude",
                            to: "double",
                            onNull: 0.0,
                            onError:0.0
                        }
                    },
                    {
                        $convert: {
                            input: "$location.coordinates.latitude",
                            to: "double",
                            onNull: 0.0,
                            onError:0.0
                        }
                    }
                ]
            }
        }
    },
    {
        $out:"transformedusers"
    }
]).pretty()


// mapReduce
// X  -> can't make use of indexes
// X -> have to write javascript functions
// X -> not following the write/flow order

//older way : mapReduce()
// New way : Aggregation Pipleline introduced in MongoDB 2.2
db.users.mapReduce(
    function () { emit(this.nat, 1) },
    function (keys, values) { return Array.sum(values) },
    {
        query: { 'gender': 'male' },
        out:"male_users_nat"
    }
)

// Indexes
db.users.createIndex({ "dob.age": 1 }) 

db.users.explain("executionStats").find({ "dob.age": { $gt: 70 }})