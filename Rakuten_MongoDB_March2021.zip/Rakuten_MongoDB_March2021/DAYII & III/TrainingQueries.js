//Implicit AND
db.courses.find({ "duration": "24 Hours", "price": 3000 }).pretty()

// $in
db.courses.find({ "title": { $in: ["React", "Angular"] } }).pretty()

// $nin
db.courses.find({ "title": { $nin: ["React", "Angular"] } }).pretty()

// mongoimport 
mongoimport--db usersdb--collection users--file users.json--jsonArray 

// Implicit AND
db.users.find({ "dob.age": { $gt: 30 }, "nat": "CA" })

// using $or
db.users.find({ $or: [{ "dob.age": { $gt: 30 } }, { "nat": "CA" }] }).pretty().limit(5)
// skip and limit and sort
db.users.find({ $or: [{ "dob.age": { $gt: 30 } }, { "nat": "CA" }] }).pretty().skip(5)

// sort : -1 is descending , 1 is ascending
db.users.find({ $or: [{ "dob.age": { $gt: 30 } }, { "nat": "CA" }] }).pretty().sort({"dob.age":1}).limit(5)

// Simple Aggregation pipeline

db.users.aggregate([
    { $match: { "gender": "male" } },
    { $group: { _id: { nat: "$nat" }, "usercount": { $sum: 1 } } },
    {$sort:{"usercount":1}}
]).pretty();

// To find users with age > 50 by gender,
// find avg age & number of users corresponding to that group
// & sort them descending

db.users.aggregate([
    { $match: { "dob.age": { $gt: 50 } } },
    { $group: { _id: { gender: "$gender" }, averageAge: { $avg: "$dob.age" }, usercount: { $sum: 1 } } },
    { $sort: {usercount:-1}}
]).pretty()


// the Project stage
db.users.aggregate([
    {
        $project: {
            _id: 0,           
            fullname: {
                $concat: [
                    { $toUpper: { $substrCP: ["$name.first", 0, 1] } },
                    {
                        $substrCP: [
                            "$name.first", 1, {
                                $subtract:[{$strLenCP:"$name.first"},1]
                            }
                        ]
                    },
                    " ",
                    { $toUpper: { $substrCP: ["$name.last", 0, 1] } },
                    {
                        $substrCP: [
                            "$name.last", 1, {
                                $subtract:[{$strLenCP:"$name.last"},1]
                            }
                        ]
                    },    
                ]
            },
            gender: 1,
            age: "$dob.age",
            location: {
                coordinates: [
                    {
                        $convert: {
                            input: "$location.coordinates.longitude",
                            to: "double",
                            onNull: 0.0,
                            onError:0.0
                        }
                    },
                    {
                        $convert: {
                            input: "$location.coordinates.latitude",
                            to: "double",
                            onNull: 0.0,
                            onError:0.0
                        }
                    }
                ]
            }
        }
    },
    {
        $out:"transformedusers"
    }
]).pretty()


// mapReduce
// X  -> can't make use of indexes
// X -> have to write javascript functions
// X -> not following the write/flow order

//older way : mapReduce()
// New way : Aggregation Pipleline introduced in MongoDB 2.2
db.users.mapReduce(
    function () { emit(this.nat, 1) },
    function (keys, values) { return Array.sum(values) },
    {
        query: { 'gender': 'male' },
        out:"male_users_nat"
    }
)

// Indexes
db.users.createIndex({ "dob.age": 1 }) 

db.users.explain("executionStats").find({ "dob.age": { $gt: 70 } })

//get Indexes
db.users.getIndexes()
// drop Index
db.users.dropIndex({"dob.age":1})
// compound Index
db.users.createIndex({"dob.age":1,"gender":1}) 

db.users.explain("executionStats").find({ "dob.age": { $gt: 60 }, "gender": "male" }) 
db.users.explain("executionStats").find({ "dob.age": { $gt: 60 } }) 
db.users.explain("executionStats").find({"gender":"female"}) 

db.products.insertMany([
    { title: 'Laptop', description: 'It is a need for an hour. It also must have a camera' },
    {title:'TV',description:'It is used for entainment'}
    
])

db.products.createIndex({"description":"text"})

db.products.find({ $text: {$search:"camera"}})

db.products.find({ $text: {$search:"\"camera is professional\""}})

db.products.insertMany([
    { title: 'Laptop', description: 'It is a need for an hour. It also must have a camera' },
    {title:'TV',description:'It is used for entainment'}
    
])

db.products.find({ $text: { $search: "professional camera" } }, {score:{$meta:'textScore'}})


db.products.find({ $text: { $search: "professional camera" } }, {score:{$meta:'textScore'}}).sort({score:1}).pretty() 


// Wankhede Stadium - 18.9390354947439, 72.8262038494082


db.places.insertOne({
    name: 'Wankhede Stadium',
    location: {
        type: 'Point',
        coordinates:[72.8262038494082,18.9390354947439]
    }
})

db.places.insertOne({
    name: 'INOX',
    location: {
        type: 'Point',
        coordinates:[ 72.82899334675568,18.943257019601816]
    }
})


// Marine Drive : 18.93593017032731, 72.82384350555984

db.places.createIndex({location:"2dsphere"})


// search for a single point [long , lat]
db.places.find({
    location: {
        $near: {
            $geometry: {
                type: 'Point',
                coordinates:[72.82384350555984,18.93593017032731]
            },
            $minDistance: 10, // meters
            $maxDistance: 500
        }
    }
});


// Provide polygon (collection) of Points[long,lat]
const point1 = [72.82384350555984, 18.93593017032731]; // marine drive
const point2 = [72.82770588631921,18.936457876561306 ]; // GST Bhavan
const point3 = [72.82730891939178,18.941663812387432]; // Liberty Cinema
const point4 = [ 72.82403662460638,18.943774554943527]; // state bank


db.places.find({
    location: {
        $geoWithin: {
            $geometry: {
                type: 'Polygon',
                coordinates:[[point1,point2,point3,point4,point1]]
           }
       }
    }
})