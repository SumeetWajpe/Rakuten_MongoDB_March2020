// Updating one record
db.courses.updateOne(
  { title: "MongoDB" },
  {
    $set: {
      price: 5000,
    },
  }
);

// updating multiple records
db.courses.updateMany(
  {},
  {
    $set: {
      likes: 500,
    },
  }
);

// update  | Http Patch / Put
db.courses.update(
  { title: "MongoDB" },
  {
    noOfTrainings: 10,
  }
);

// deleteOne, deleteMany
db.courses.deleteOne({ noOfTrainings: 10 });

// update
db.courses.updateMany(
  { duration: "24 Hours" },
  { $set: { markedForDelete: true } }
);

//delete
db.courses.deleteMany({ markedForDelete: true });

// projection
db.courses
  .find({ price: { $gt: 3000 } }, { title: 1, likes: 1, _id: 0 })
  .pretty();

// embedded document
db.courses.updateMany(
  {},
  {
    $set: {
      venue: {
        type: "online",
        vendor: "Pluralsight",
      },
    },
  }
);

// projection
db.courses
    .find({ "venue.type": { $eq: "online" } },
        { title: 1, likes: 1, _id: 0 })
  .pretty();
